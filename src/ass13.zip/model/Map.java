package model;

public class Map {
	private Component farmer;
	private Component goose;
	private Component bean;
	private Component fox;
	private Ship ship;
	private int shipPosition;
	private int farmerPosition;
	
	private int goosePosition;
	private int beanPosition;
	private int foxPosition;


	public Map(Component farmer, Component goose, Component bean, Component fox, Ship ship) {
		super();
		this.farmer = farmer;
		this.goose = goose;
		this.bean = bean;
		this.fox = fox;
		this.ship = ship;
		this.shipPosition = 1;
		this.farmerPosition = 2;
		this.goosePosition = 2;
		this.beanPosition = 2;
		this.foxPosition = 2;

	}
	private int moveShip(int direction){
		if(farmerPosition == 1){
			if(direction == shipPosition){
				return 0;
			}
			shipPosition = direction;
			return 1;
		}
		return 0;
	}
	private int embark(Component component){
		// 0: farmer
		// 1: goose
		// 2: bean
		// 3: fox
		switch(component.id){
		case 0:
			if(ship.add(farmer)){
				farmerPosition = 1;
				return 2;
			}
			break;
		case 1:
			if(ship.add(goose)){
				goosePosition = 1;
				return 2;
			}
			break;
		case 2:
			if(ship.add(bean)){
				beanPosition = 1;
				return 2;
			}
			break;
		case 3:
			if(ship.add(fox)){
				foxPosition = 1;
				return 2;
			}
			break;

		}
		return 0;
	}
	private int debark(Component component){
		// 0: farmer
		// 1: goose
		// 2: bean
		// 3: fox
		switch(component.id){
		case 0:
			if(ship.remove(farmer)){
				System.out.println("farmer removed");
				if(shipPosition == 0){
					System.out.println("farmer position is set 0");
				farmerPosition = 0;
				}else{
					farmerPosition = 2;
				}
				return 3;
			}
			break;
		case 1:
			if(ship.remove(goose)){
				if(shipPosition == 0){
				goosePosition = 0;
				}else{
					goosePosition = 2;
				}
				return 3;
			}
			break;
		case 2:
			if(ship.remove(bean)){
				if(shipPosition == 0){
				beanPosition = 0;
				}else{
					beanPosition = 2;
				}
				return 3;
			}
			break;
		case 3:
			if(ship.remove(fox)){
				if(shipPosition == 0){
					foxPosition = 0;
				}else{
					foxPosition = 2;
				}
				return 3;
			}
			break;

		}
		return 0;
	}

	public int move(Component component, int direction){
		System.out.println("direction "+ direction);
		System.out.println("ship position : " + shipPosition);
		switch(component.id){
		case 0:
			
			if(farmerPosition == 1){

				if(shipPosition == direction){
					System.out.println("debarking");
					return debark(farmer);
				}
			}
			else if(farmerPosition == direction){
				return 0;
			}else{
				return embark(farmer);
			}
			break;
		case 1:
			if(goosePosition == 1){
				if(shipPosition == direction){
					return debark(goose);
				}
			}
			else if(goosePosition == direction){
				return 0;
			}else{
				return embark(goose);
			}
			break;
		case 2:
			if(beanPosition == 1){
				if(shipPosition == direction){
					return debark(bean);
				}
			}
			else if(beanPosition == direction){
				return 0;
			}else{
				return embark(bean);
			}
			break;
		case 3:
			if(foxPosition == 1){
				if(shipPosition == direction){
					return debark(fox);
				}
			}
			else if(foxPosition == direction){
				return 0;
			}else{
				return embark(fox);
			}
			break;
		case 4:
			return moveShip(direction);
		}
		return 0;
	}
	public boolean hasLost(){
		if(goosePosition == beanPosition){
			return true;
		}else if(foxPosition == goosePosition){
			return true;
		}
		return false;
	}
	
	
//	public Component getFarmer() {
//		return farmer;
//	}
//	public void setFarmer(Component farmer) {
//		this.farmer = farmer;
//	}
//	public Component getGoose() {
//		return goose;
//	}
//	public void setGoose(Component goose) {
//		this.goose = goose;
//	}
//	public Component getBean() {
//		return bean;
//	}
//	public void setBean(Component bean) {
//		this.bean = bean;
//	}
//	public Component getFox() {
//		return fox;
//	}
//	public void setFox(Component fox) {
//		this.fox = fox;
//	}
//	public Ship getShip() {
//		return ship;
//	}
//	public void setShip(Ship ship) {
//		this.ship = ship;
//	}
//	public int getShipPosition() {
//		return shipPosition;
//	}
//	public void setShipPosition(int shipPosition) {
//		this.shipPosition = shipPosition;
//	}
//	public int getFarmerPosition() {
//		return farmerPosition;
//	}
//	public void setFarmerPosition(int farmerPosition) {
//		this.farmerPosition = farmerPosition;
//	}
//	public int getGoosePosition() {
//		return goosePosition;
//	}
//	public void setGoosePosition(int goosePosition) {
//		this.goosePosition = goosePosition;
//	}
//	public int getBeanPosition() {
//		return beanPosition;
//	}
//	public void setBeanPosition(int beanPosition) {
//		this.beanPosition = beanPosition;
//	}
//	public int getFoxPosition() {
//		return foxPosition;
//	}
//	public void setFoxPosition(int foxPosition) {
//		this.foxPosition = foxPosition;
//	}

}
