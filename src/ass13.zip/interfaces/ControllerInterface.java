package interfaces;

public interface ControllerInterface {
	public int move(int id, int direction);
}
