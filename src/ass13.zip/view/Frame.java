package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.Graphics;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import controller.Game;
import interfaces.*;


public class Frame extends JFrame {

	private JLabel boat; 
	private JButton boatback;
	private JButton boatfort;
	private JLabel fox; 
	private JButton foxback;
	private JButton foxfort;
	private JLabel goose; 
	private JButton gooseback;
	private JButton goosefort;
	private JLabel beans; 
	private JButton beansback;
	private JButton	beansfort;
	private JLabel farmer; 
	private JButton farmerback;
	private JButton farmerfort;
	
	private JLabel rightWaterImageLabel;
	private JLabel leftWaterImageLabel;
	
	private JLabel beanImageLabelEast;
	private JLabel farmerImageLabelEast;
	private JLabel gooseImageLabelEast; 
	private JLabel foxImageLabelEast; 
	private JLabel grassImageLabel;
	private ImagePanel pane1East;
	private ImagePanel pane2East;
	private ImagePanel pane3East;
	private ImagePanel pane4East;
	private JLabel beanImageLabelWest;
	private JLabel farmerImageLabelWest;
	private JLabel gooseImageLabelWest; 
	private JLabel foxImageLabelWest; 
	private ImagePanel pane1West;
	private ImagePanel pane2West;
	private ImagePanel pane3West;
	private ImagePanel pane4West;
	private JLabel sailingLabelRight;
	private JLabel sailingLabelLeft;
	private ImagePanel pane;
	private ImagePanel panewaterright;
	private ImagePanel panewaterleft;
	private ControllerInterface cInterface;
	private JPanel boatPanelRight = new JPanel(new GridLayout(2,1));
	private JPanel boatPanelLeft = new JPanel(new GridLayout(2,1));

	public Frame(ImageIcon farmerIcon,ImageIcon gooseIcon,ImageIcon beanIcon,ImageIcon foxIcon,ImageIcon shipIcon, Game game){
		cInterface = game;
		Frame frame = this;
		
		
		try {
	         BufferedImage waterImg = ImageIO.read(new File("src/water.jpg"));
	         ImageIcon waterIcon = new ImageIcon(waterImg);
	         
	       
	         BufferedImage grassImage = ImageIO.read(new File("src/grass.jpg"));
	         ImageIcon grassIcon = new ImageIcon(grassImage);
	         Image image = grassIcon.getImage(); // transform it 
	         Image newimg = image.getScaledInstance(200, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
	         grassIcon = new ImageIcon(newimg);  // transform it back
	         
	         grassImageLabel = new JLabel(grassIcon);
	         
	         
	      } catch (IOException e) {
	         e.printStackTrace();
	      }
		beanImageLabelEast = new JLabel(beanIcon);
        farmerImageLabelEast = new JLabel(farmerIcon);
        gooseImageLabelEast = new JLabel(gooseIcon);
        foxImageLabelEast = new JLabel(foxIcon);
        sailingLabelRight = new JLabel(shipIcon);
        // sailingLabelLeft = new JLabel(shipIcon);
        beanImageLabelWest = new JLabel(beanIcon);

        farmerImageLabelWest = new JLabel(farmerIcon);
        gooseImageLabelWest = new JLabel(gooseIcon);
        foxImageLabelWest = new JLabel(foxIcon);
		boat = new JLabel("Boat");
		fox = new JLabel("Fox");
		goose = new JLabel("Goose");
		beans = new JLabel("Beans");
		farmer = new JLabel("Farmer");
		
		
		boatback = new JButton(" < ");
		boatfort = new JButton(" > ");
		
		foxback = new JButton(" < ");
		foxfort = new JButton(" > ");
		
		gooseback = new JButton(" < ");
		goosefort = new JButton(" > ");
		
		beansback = new JButton(" < ");
		beansfort = new JButton(" > ");
		
		farmerback = new JButton(" < ");
		farmerfort = new JButton(" > ");
		
		setLayout(new BorderLayout());

		JPanel jpCenter = new JPanel();
		JPanel jpWest = new JPanel();
		JPanel jpEast = new JPanel();
		JPanel jpSouth = new JPanel();
		
		
		this.add(jpCenter, BorderLayout.CENTER);
		this.add(jpWest, BorderLayout.WEST);
		this.add(jpEast, BorderLayout.EAST);
		this.add(jpSouth, BorderLayout.SOUTH);
		
	
		
		
		jpSouth.setLayout(new GridLayout(1, 15));
		jpSouth.add(boat);
		jpSouth.add(boatback);
		jpSouth.add(boatfort);
		jpSouth.add(fox);
		jpSouth.add(foxback);
		jpSouth.add(foxfort);
		jpSouth.add(goose);
		jpSouth.add(gooseback);
		jpSouth.add(goosefort);
		jpSouth.add(beans);
		jpSouth.add(beansback);
		jpSouth.add(beansfort);
		jpSouth.add(farmer);
		jpSouth.add(farmerback);
		jpSouth.add(farmerfort);

        try {
			BufferedImage grassImage = ImageIO.read(new File("src/grass.jpg"));
			pane1East = new ImagePanel(grassImage);
			pane2East = new ImagePanel(grassImage);
			pane3East = new ImagePanel(grassImage);
			pane4East = new ImagePanel(grassImage);
			pane1West = new ImagePanel(grassImage);
			pane2West = new ImagePanel(grassImage);
			pane3West = new ImagePanel(grassImage);
			pane4West = new ImagePanel(grassImage);
			BufferedImage waterImage = ImageIO.read(new File("src/water.jpg"));
			panewaterright = new ImagePanel(waterImage);
			panewaterleft = new ImagePanel(waterImage);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		boatPanelRight.add(sailingLabelRight);
		JPanel obejctsInTheboat = new JPanel(new GridLayout(1,2));
		boatPanelRight.add(obejctsInTheboat);
		
		boatPanelRight.setOpaque(false);
		obejctsInTheboat.setOpaque(false);
		
		panewaterright.add(boatPanelRight);
		

		//boatPanelLeft.add(sailingLabelLeft);
		JPanel obejctsInTheboat2 = new JPanel(new GridLayout(1,2));
		boatPanelLeft.add(obejctsInTheboat2);
		
		boatPanelLeft.setOpaque(false);
		obejctsInTheboat2.setOpaque(false);
		
		panewaterleft.add(boatPanelLeft);
		
		
		jpCenter.setLayout(new GridLayout(1,2));		
		jpCenter.add(panewaterleft);
		jpCenter.add(panewaterright);
		
		
		beanImageLabelEast.setHorizontalAlignment(JLabel.CENTER);
		beanImageLabelEast.setVerticalAlignment(JLabel.CENTER);
		
		farmerImageLabelEast.setHorizontalAlignment(JLabel.CENTER);
		farmerImageLabelEast.setVerticalAlignment(JLabel.CENTER);
		
		gooseImageLabelEast.setHorizontalAlignment(JLabel.CENTER);
		gooseImageLabelEast.setVerticalAlignment(JLabel.CENTER);
		
		foxImageLabelEast.setHorizontalAlignment(JLabel.CENTER);
		foxImageLabelEast.setVerticalAlignment(JLabel.CENTER);
		
		beanImageLabelEast.setPreferredSize(new Dimension(250,250));
		farmerImageLabelEast.setPreferredSize(new Dimension(250,250));
		gooseImageLabelEast.setPreferredSize(new Dimension(250,250));
		foxImageLabelEast.setPreferredSize(new Dimension(250,250));
		
		beanImageLabelWest.setPreferredSize(new Dimension(250,250));
		farmerImageLabelWest.setPreferredSize(new Dimension(250,250));
		gooseImageLabelWest.setPreferredSize(new Dimension(250,250));
		foxImageLabelWest.setPreferredSize(new Dimension(250,250));
		
		pane1East.add(beanImageLabelEast);
		pane2East.add(farmerImageLabelEast);
		pane3East.add(gooseImageLabelEast);
		pane4East.add(foxImageLabelEast);
		
		pane1West.setPreferredSize(new Dimension(250,250));
		pane2West.setPreferredSize(new Dimension(250,250));
		pane3West.setPreferredSize(new Dimension(250,250));
		pane4West.setPreferredSize(new Dimension(250,250));
//		pane1East.setPreferredSize(n);

		

	
		jpEast.setLayout(new GridLayout(4,1));
		jpWest.setLayout(new GridLayout(4,1));
//		jpEast.add(grassImageLabel);
		jpEast.add(pane1East);
		jpEast.add(pane2East);
		jpEast.add(pane3East);
		jpEast.add(pane4East);
		
		jpWest.add(pane1West);
		jpWest.add(pane2West);
		jpWest.add(pane3West);
		jpWest.add(pane4West);
		
		boatback.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(cInterface.move(4, 0) == 1){
					System.out.println(true);
					panewaterleft.add(boatPanelRight);
					SwingUtilities.updateComponentTreeUI(frame);
				}else{
					System.out.println(false);
				}
			}
		});
		boatfort.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(cInterface.move(4, 1) == 1){
					System.out.println(true);
					panewaterright.add(boatPanelRight);
					SwingUtilities.updateComponentTreeUI(frame);
				}else{
					System.out.println(false);
				}
				
			}
		});
		
		farmerback.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int result = cInterface.move(0, 0);
				System.out.println("result : " + result);
				if(result == 2){
					System.out.println(2);
					obejctsInTheboat.add(farmerImageLabelEast);

				}else if(result == 3){
					System.out.println(3);
					pane2West.add(farmerImageLabelEast);
				}else{
					System.out.println(false);
				}
				SwingUtilities.updateComponentTreeUI(frame);
			}
		});
		farmerfort.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int result = cInterface.move(0, 1);
				System.out.println(result);
				if(result == 2){
					obejctsInTheboat.add(farmerImageLabelEast);
				}else if(result == 3){
					pane2East.add(farmerImageLabelEast);
				}else{
					System.out.println(false);
				}
				SwingUtilities.updateComponentTreeUI(frame);
			}
		});
		
		gooseback.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cInterface.move(1, 1);
			}
		});
		goosefort.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cInterface.move(1, 0);
			}
		});
		
		beansback.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cInterface.move(2, 1);
			}
		});
		beansfort.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cInterface.move(2, 0);
			}
		});
		foxback.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cInterface.move(3, 1);
			}
		});
		foxfort.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				cInterface.move(3, 0);
			}
		});
		
		this.pack();
		this.setVisible(true);
		
//		foxImageLabelEast.setVisible(false);
	
	}
	

}
