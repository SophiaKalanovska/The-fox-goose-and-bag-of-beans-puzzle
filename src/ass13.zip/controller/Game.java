package controller;

import view.Frame;

import java.io.IOException;

import javax.swing.ImageIcon;

import model.*;
import interfaces.*;

public class Game implements ControllerInterface {
	public Map map;
	public Component farmer;
	public Component goose;
	public Component bean;
	public Component fox;
	public Ship ship;
	public boolean hasLost;
	public static Game game;
	public static void main(String[]args){
		
		game = new Game();
		game.farmer = new Component("src/farmer.png",0);
		game.goose = new Component("src/goose.png",1);
		game.bean = new Component("src/beans.png",2);
		game.fox = new Component("src/fox.png",3);
		game.ship = new Ship();
		game.map = new Map(game.farmer, game.goose, game.bean, game.fox, game.ship);
		try {
			Frame game = new Frame(getFarmerImage(),
					getGooseImage(),
					getBeanImage(),
					getFoxImage(),
					getShipImage(),
					Game.game);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
    }
	public Game(){
		
	}
	public static ImageIcon getFarmerImage() throws IOException{
		return game.farmer.getImage();
	}
	public static ImageIcon getGooseImage() throws IOException{
		return game.goose.getImage();
	}
	public static ImageIcon getBeanImage() throws IOException{
		return game.bean.getImage();
	}
	public static ImageIcon getFoxImage() throws IOException{
		return game.fox.getImage();
	}
	public static ImageIcon getShipImage() throws IOException{
		return game.ship.getImage();
	}

	@Override
	public int move(int id, int direction) {
		// TODO Auto-generated method stub
		if(hasLost != true){
			System.out.println("Not looser");
		switch(id){
		case 0:
			return map.move(farmer, direction);
		case 1:
			return map.move(goose, direction);
		case 2:
			return map.move(bean, direction);
		case 3:
			return map.move(fox,direction);
		case 4:
			return map.move(ship, direction);
		}
		hasLost = map.hasLost();
		}
		return 0;
	}
}
